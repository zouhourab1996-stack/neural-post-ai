import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SITE_URL = "https://prophetic.pw";
const BING_INDEXNOW_KEY = "a0ed604574874b10b1d2245fd9eeaed8";

function getCurrentDate(): string {
  return new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

function getISODate(): string {
  return new Date().toISOString().split('T')[0];
}

async function fetchNewsAPIHeadlines(category: string, apiKey: string) {
  try {
    const categoryMap: Record<string, string> = { AI: 'technology', Tech: 'technology', Business: 'business', Science: 'science' };
    const response = await fetch(`https://newsapi.org/v2/top-headlines?category=${categoryMap[category]||'technology'}&language=en&pageSize=10&apiKey=${apiKey}`);
    if (!response.ok) return { headlines: [] };
    const data = await response.json();
    if (!data.articles?.length) return { headlines: [] };
    return {
      headlines: data.articles
        .filter((a: any) => a.title && a.title !== '[Removed]')
        .slice(0, 5)
        .map((a: any) => ({ title: a.title, source: a.source?.name || 'Unknown', url: a.url || '', description: a.description || '' }))
    };
  } catch { return { headlines: [] }; }
}

async function fetchPexelsImage(query: string, apiKey: string): Promise<string | null> {
  try {
    const response = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(query.slice(0,100))}&per_page=5&orientation=landscape`, { headers: { Authorization: apiKey } });
    if (!response.ok) return null;
    const data = await response.json();
    if (data.photos?.length) {
      const idx = Math.floor(Math.random() * Math.min(5, data.photos.length));
      return data.photos[idx].src.large2x || data.photos[idx].src.large;
    }
    return null;
  } catch { return null; }
}

async function discoverKeywords(headline: string, category: string, apiKey: string) {
  try {
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: 'You are an SEO expert. Always respond with valid JSON only.' },
          { role: 'user', content: `For the news headline: "${headline}" (Category: ${category})\n\nIdentify 4-5 high-value SEO keywords. Return ONLY valid JSON:\n{"keywords":[{"keyword":"phrase 2026","volume":"high","competition":"low"}]}` }
        ],
        temperature: 0.7, max_tokens: 500,
      }),
    });
    if (!response.ok) return { keywords: [] };
    const data = await response.json();
    const parsed = JSON.parse(data.choices?.[0]?.message?.content?.replace(/```json\n?|\n?```/g, '').trim() || '{}');
    return { keywords: parsed.keywords || [] };
  } catch { return { keywords: [] }; }
}

async function generateArticleWithDeepSeek(headline: string, description: string, source: string, keywords: any[], category: string, apiKey: string): Promise<any> {
  const currentDate = getCurrentDate();
  const primaryKeyword = keywords[0]?.keyword || headline.split(' ').slice(0, 3).join(' ');
  const keywordList = keywords.map((k: any) => k.keyword).join(', ');

  const prompt = `You are a senior tech journalist at TechCrunch. Today is ${currentDate}.

BREAKING NEWS: "${headline}"
Source: ${source}
Brief: ${description}

Write a comprehensive, analytical article (minimum 1,500 words).

SEO REQUIREMENTS:
- Primary Keyword: "${primaryKeyword}"
- Secondary Keywords: ${keywordList}
- Include primary keyword in H1, first paragraph, 2+ H2 subheadings
- Keyword density: 1-2%

FRESHNESS (CRITICAL for Google ranking):
- Mention today's date: ${currentDate}
- Use "today", "this week", "2026" naturally

WRITING STYLE:
- Analytical, authoritative, engaging — HUMAN-LIKE
- Include data, statistics, expert perspectives
- Break up text with bullet points, quotes, subheadings

STRUCTURE (minimum 1,500 words):
1. H1: SEO-optimized, includes primary keyword, under 60 chars
2. Hook/Lead paragraph with keyword
3. Context (H2): Background and why this matters now
4. Deep Dive (H2): Core story with details and data
5. Analysis (H2): Expert analysis and implications  
6. Industry Impact (H2): Effect on ${category} landscape
7. What's Next (H2): Future predictions and timeline
8. Key Takeaways: bullet-point summary

UNIQUE META DESCRIPTION: Write a unique, specific meta description (150-155 chars) that describes THIS article — NOT a generic template.

Return ONLY valid JSON:
{
  "title": "SEO headline under 60 chars with keyword",
  "meta_description": "Unique compelling description 150-155 chars with keyword and specific CTA for THIS article",
  "slug": "url-friendly-slug-with-primary-keyword",
  "content": "Full markdown article minimum 1500 words",
  "image_query": "2-3 word image search term"
}`;

  const response = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [
        { role: 'system', content: 'You are an elite tech journalist. Write comprehensive, SEO-optimized articles. Always respond with valid JSON. Minimum 1500 words.' },
        { role: 'user', content: prompt }
      ],
      temperature: 0.75, max_tokens: 5000,
    }),
  });

  if (!response.ok) throw new Error(`DeepSeek API error: ${response.status}`);
  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) throw new Error('No content from DeepSeek');
  
  return JSON.parse(content.replace(/```json\n?|\n?```/g, '').trim());
}

// Submit newly published URL to Bing IndexNow immediately after publishing
async function notifyBingIndexNow(url: string) {
  try {
    const response = await fetch("https://api.indexnow.org/indexnow", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({
        host: "prophetic.pw",
        key: BING_INDEXNOW_KEY,
        keyLocation: `${SITE_URL}/${BING_INDEXNOW_KEY}.txt`,
        urlList: [url],
      }),
    });
    const status = response.status;
    console.log(`Bing IndexNow: ${url} → ${status}`);
    return status === 200 || status === 202;
  } catch (e) {
    console.error("Bing IndexNow error:", e);
    return false;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const { category, autoPublish = false } = await req.json();

    const NEWSAPI_KEY = Deno.env.get('NEWSAPI_KEY');
    const DEEPSEEK_API_KEY = Deno.env.get('DEEPSEEK_API_KEY');
    const PEXELS_API_KEY = Deno.env.get('PEXELS_API_KEY');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!NEWSAPI_KEY) throw new Error('NEWSAPI_KEY is not configured');
    if (!DEEPSEEK_API_KEY) throw new Error('DEEPSEEK_API_KEY is not configured');

    const validCategories = ['AI', 'Tech', 'Business', 'Science'];
    const selectedCategory = validCategories.includes(category) ? category : 'AI';

    console.log(`[${new Date().toISOString()}] Generating article for: ${selectedCategory}`);

    // Phase 1: Fetch headlines
    const { headlines } = await fetchNewsAPIHeadlines(selectedCategory, NEWSAPI_KEY);
    if (headlines.length === 0) throw new Error('No headlines found from NewsAPI');

    const selectedHeadline = headlines[0];
    console.log(`Headline: ${selectedHeadline.title}`);

    // Phase 2: Discover SEO keywords
    const { keywords } = await discoverKeywords(selectedHeadline.title, selectedCategory, DEEPSEEK_API_KEY);
    console.log(`Keywords: ${keywords.map((k: any) => k.keyword).join(', ')}`);

    // Phase 3: Generate article (DeepSeek writes unique meta_description automatically)
    const article = await generateArticleWithDeepSeek(
      selectedHeadline.title, selectedHeadline.description, selectedHeadline.source,
      keywords, selectedCategory, DEEPSEEK_API_KEY
    );

    // Phase 4: Fetch image
    let imageUrl = null;
    if (PEXELS_API_KEY && article.image_query) {
      imageUrl = await fetchPexelsImage(article.image_query, PEXELS_API_KEY);
    }

    const finalArticle = {
      title: article.title,
      slug: article.slug + '-' + getISODate(),
      meta_description: article.meta_description, // Unique description from DeepSeek
      content: article.content,
      category: selectedCategory,
      image_url: imageUrl,
      is_featured: Math.random() > 0.5,
      is_trending: true,
    };

    // Phase 5: Auto-publish + notify Bing IndexNow
    if (autoPublish && SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY) {
      const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

      const { data: savedArticle, error: articleError } = await supabase
        .from('articles').insert(finalArticle).select().single();

      if (articleError) throw new Error(`Failed to save article: ${articleError.message}`);

      // Save keywords
      const keywordsToSave = [
        ...keywords.map((k: any) => ({ keyword: k.keyword, category: selectedCategory, search_volume: k.volume, competition: k.competition, discovered_at: getISODate() })),
        { keyword: selectedHeadline.title.slice(0, 100), category: selectedCategory, search_volume: 'high', competition: 'low', discovered_at: getISODate() },
      ];
      await supabase.from('trending_keywords').insert(keywordsToSave);

      // Immediately notify Bing IndexNow about the new article
      const articleUrl = `${SITE_URL}/article/${savedArticle.slug}/`;
      await notifyBingIndexNow(articleUrl);

      console.log(`✅ Published: ${savedArticle.title}`);

      return new Response(JSON.stringify({
        success: true, article: savedArticle, keywords: keywordsToSave,
        headline: selectedHeadline, allHeadlines: headlines, published: true,
        bingNotified: true, articleUrl
      }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
    }

    return new Response(JSON.stringify({
      success: true, article: finalArticle, keywords,
      headline: selectedHeadline, allHeadlines: headlines, published: false
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('Error in generate-article:', error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
