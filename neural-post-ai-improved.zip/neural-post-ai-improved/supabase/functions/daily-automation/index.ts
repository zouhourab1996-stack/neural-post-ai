import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SITE_URL = "https://prophetic.pw";
const BING_INDEXNOW_KEY = "a0ed604574874b10b1d2245fd9eeaed8";

async function submitBatchToBing(urls: string[]) {
  if (!urls.length) return;
  try {
    const response = await fetch("https://api.indexnow.org/indexnow", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({
        host: "prophetic.pw",
        key: BING_INDEXNOW_KEY,
        keyLocation: `${SITE_URL}/${BING_INDEXNOW_KEY}.txt`,
        urlList: urls,
      }),
    });
    console.log(`Bing IndexNow batch submit: ${response.status} for ${urls.length} URLs`);
  } catch (e) {
    console.error("Bing IndexNow batch error:", e);
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) throw new Error('Supabase configuration missing');

    console.log(`[${new Date().toISOString()}] Starting daily automation...`);

    const categories = ['AI', 'Tech', 'Business', 'Science'];
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000);

    // Generate 2 articles per run, rotating through all 4 categories
    const categoriesToGenerate = [
      categories[dayOfYear % 4],
      categories[(dayOfYear + 1) % 4],
    ];

    const results = [];
    const publishedUrls: string[] = [];

    for (const category of categoriesToGenerate) {
      console.log(`Generating article for: ${category}`);
      const response = await fetch(`${SUPABASE_URL}/functions/v1/generate-article`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ category, autoPublish: true }),
      });

      const result = await response.json();
      results.push({ category, ...result });

      if (result.success && result.article?.slug) {
        publishedUrls.push(`${SITE_URL}/article/${result.article.slug}/`);
      }

      console.log(`Article for ${category}: ${result.success ? '✅' : '❌'}`);

      // Wait 5 seconds between generations to avoid rate limiting
      if (category !== categoriesToGenerate[categoriesToGenerate.length - 1]) {
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }

    // Clean up old keywords (keep last 7 days)
    if (SUPABASE_SERVICE_ROLE_KEY) {
      const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      await supabase.from('trending_keywords').delete().lt('discovered_at', sevenDaysAgo.toISOString().split('T')[0]);
    }

    // Submit newly published articles + homepage to Bing IndexNow
    const bingUrls = [`${SITE_URL}/`, ...publishedUrls];
    await submitBatchToBing(bingUrls);

    // Also trigger Google Indexing for new articles
    if (publishedUrls.length > 0) {
      try {
        await fetch(`${SUPABASE_URL}/functions/v1/google-indexing`, {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ urls: publishedUrls, action: 'URL_UPDATED' }),
        });
        console.log(`Google Indexing triggered for ${publishedUrls.length} URLs`);
      } catch (e) {
        console.error('Google indexing trigger failed (non-critical):', e);
      }
    }

    console.log(`[${new Date().toISOString()}] Automation completed. Published: ${publishedUrls.length}`);

    return new Response(JSON.stringify({
      success: true,
      message: 'Daily automation completed',
      results,
      publishedUrls,
      bingNotified: bingUrls.length,
      generatedAt: new Date().toISOString()
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });

  } catch (error) {
    console.error('Daily automation error:', error);
    return new Response(JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
