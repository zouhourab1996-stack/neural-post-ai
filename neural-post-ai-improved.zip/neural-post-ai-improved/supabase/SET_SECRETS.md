# Setting Supabase Edge Function Secrets

## Method 1: Supabase Dashboard (Recommended)
1. Go to: https://supabase.com/dashboard/project/bltytefghazluwicnaii/settings/edge-functions
2. Add these secrets:
   - `DEEPSEEK_API_KEY` = `sk-dd9a79309e0c462a9004cd575ea1b3c6`
   - `BING_INDEXNOW_KEY` = `a0ed604574874b10b1d2245fd9eeaed8`

## Method 2: Supabase CLI
```bash
supabase secrets set DEEPSEEK_API_KEY=sk-dd9a79309e0c462a9004cd575ea1b3c6
supabase secrets set BING_INDEXNOW_KEY=a0ed604574874b10b1d2245fd9eeaed8
```
