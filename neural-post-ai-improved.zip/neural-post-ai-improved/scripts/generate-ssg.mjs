/**
 * NeuralPost Static Site Generation Script
 * =========================================
 * - Generates pre-rendered HTML for all routes
 * - Generates sitemap-articles.xml (dynamic) + sitemap-static.xml + rss.xml
 * - Submits new URLs to Bing IndexNow API automatically
 * - Uses DeepSeek to auto-generate unique meta descriptions if missing
 */

import { createClient } from "@supabase/supabase-js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const SITE_URL = "https://prophetic.pw";
const SITE_NAME = "NeuralPost";
const DEFAULT_IMAGE = "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=1200";
const BING_INDEXNOW_API_KEY = process.env.BING_INDEXNOW_API_KEY || "a0ed604574874b10b1d2245fd9eeaed8";
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || process.env.VITE_DEEPSEEK_API_KEY;

const FALLBACK_PROJECT_ID = "bltytefghazluwicnaii";
const FALLBACK_SUPABASE_URL = `https://${FALLBACK_PROJECT_ID}.supabase.co`;
const FALLBACK_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJsdHl0ZWZnaGF6bHV3aWNuYWlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njg2NzY5MzksImV4cCI6MjA4NDI1MjkzOX0.LfH0E7PQ5kD9NpNDK0zSGSNSU3mnGvImeytOF5gqt3w";

const supabaseUrl = process.env.VITE_SUPABASE_URL || (process.env.VITE_SUPABASE_PROJECT_ID ? `https://${process.env.VITE_SUPABASE_PROJECT_ID}.supabase.co` : FALLBACK_SUPABASE_URL);
const supabaseKey = process.env.VITE_SUPABASE_PUBLISHABLE_KEY || FALLBACK_PUBLISHABLE_KEY;

if (!supabaseUrl || !supabaseKey) { console.error("Missing Supabase credentials."); process.exit(1); }

const supabase = createClient(supabaseUrl, supabaseKey);
const categories = ["AI", "Tech", "Business", "Science"];
const categoryNames = { AI: "الذكاء الاصطناعي", Tech: "التقنية", Business: "الأعمال", Science: "العلوم" };

const staticPages = [
  { route: "/about", title: "About NeuralPost | AI-Powered Tech News", description: "NeuralPost is your trusted source for AI-powered news covering artificial intelligence, technology, business, and science with expert analysis.", heading: "About NeuralPost", content: "NeuralPost is a next-generation digital publication dedicated to covering the most important stories in AI, technology, business, and science." },
  { route: "/contact", title: "Contact NeuralPost | Editorial & Partnerships", description: "Reach out to NeuralPost for editorial questions, partnerships, press inquiries, and advertising. We respond within 24 hours.", heading: "Contact Us", content: "For editorial questions or partnership opportunities, contact us at touatihadi0@gmail.com. We typically respond within 24 hours." },
  { route: "/privacy", title: "Privacy Policy | NeuralPost", description: "Read NeuralPost's privacy policy to understand how we collect, use, and protect your personal data in compliance with GDPR and CCPA.", heading: "Privacy Policy", content: "NeuralPost respects your privacy. This policy outlines what data we collect and your rights under GDPR and CCPA regulations." },
  { route: "/terms", title: "Terms of Service | NeuralPost", description: "Read NeuralPost terms of service. Understand acceptable use, content ownership, and your responsibilities as a platform user.", heading: "Terms of Service", content: "By using NeuralPost, you agree to these terms. Content is provided for informational purposes. Republishing requires written permission." },
  { route: "/disclaimer", title: "Disclaimer | NeuralPost", description: "Important disclaimers about NeuralPost content. Articles are for informational purposes and do not constitute professional advice.", heading: "Disclaimer", content: "NeuralPost content is published for informational purposes only and should not be treated as legal, medical, or investment advice." },
];

function normalizeRoute(r) { if (!r || r === "/") return "/"; return `/${r.replace(/^\/+|\/+$/g, "")}/`; }
function toAbsoluteUrl(r) { return r === "/" || !r ? `${SITE_URL}/` : `${SITE_URL}${normalizeRoute(r)}`; }
function ensureDir(d) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); }
function writeRouteIndex(distDir, route, html) {
  const normalized = normalizeRoute(route);
  if (normalized === "/") { fs.writeFileSync(path.join(distDir, "index.html"), html, "utf8"); return; }
  const relativeDir = normalized.replace(/^\//, "").replace(/\/$/, "");
  const outputDir = path.join(distDir, relativeDir);
  ensureDir(outputDir);
  fs.writeFileSync(path.join(outputDir, "index.html"), html, "utf8");
}
function escapeHtml(t = "") { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;"); }
function stripMarkdown(m = "") { return String(m).replace(/```[\s\S]*?```/g," ").replace(/`([^`]+)`/g,"$1").replace(/!\[[^\]]*\]\([^\)]+\)/g," ").replace(/\[[^\]]+\]\([^\)]+\)/g,"$1").replace(/^#+\s+/gm,"").replace(/[>*_~\-]{1,3}/g," ").replace(/\s+/g," ").trim(); }
function normalizeDescription(d = "", min = 120, max = 160) {
  const clean = stripMarkdown(d) || `Latest AI and tech news from ${SITE_NAME}.`;
  if (clean.length < min) return (clean + ` Read exclusive coverage on ${SITE_NAME}.`).slice(0, max);
  if (clean.length > max) return `${clean.slice(0, max - 1).trim()}…`;
  return clean;
}
function markdownToHtml(md = "") {
  return md.split(/\n{2,}/).map(b => b.trim()).filter(Boolean).map(block => {
    const h1 = block.match(/^#\s+(.+)/), h2 = block.match(/^##\s+(.+)/), h3 = block.match(/^###\s+(.+)/);
    if (h1) return `<h2>${escapeHtml(h1[1])}</h2>`;
    if (h2) return `<h3>${escapeHtml(h2[1])}</h3>`;
    if (h3) return `<h4>${escapeHtml(h3[1])}</h4>`;
    const lines = block.split("\n").filter(l => l.trim());
    if (lines.length > 1 && lines.every(l => /^[-*]\s+/.test(l))) return `<ul>${lines.map(l => `<li>${escapeHtml(l.replace(/^[-*]\s+/,""))}</li>`).join("")}</ul>`;
    return `<p>${escapeHtml(block).replace(/\n/g,"<br/>")}</p>`;
  }).join("\n");
}

async function generateUniqueDescription(article) {
  if (!DEEPSEEK_API_KEY) return null;
  try {
    const prompt = `Write a unique, compelling meta description for this news article (exactly 150-155 characters, no more, no less):
Title: ${article.title}
Category: ${article.category}
Content: ${stripMarkdown(article.content || article.meta_description || "").slice(0, 300)}

Rules:
- Exactly 150-155 characters
- Include a natural call to action
- Mention the topic clearly
- NO quotation marks
- Return ONLY the description text, nothing else`;
    const response = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${DEEPSEEK_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "deepseek-chat", messages: [{ role: "user", content: prompt }], temperature: 0.7, max_tokens: 200 }),
    });
    if (!response.ok) return null;
    const data = await response.json();
    const desc = data.choices?.[0]?.message?.content?.trim();
    if (desc && desc.length >= 120 && desc.length <= 165) return desc;
    return null;
  } catch { return null; }
}

async function submitToBingIndexNow(urls) {
  if (!urls || urls.length === 0) return;
  try {
    console.log(`\n🔍 Submitting ${urls.length} URL(s) to Bing IndexNow...`);
    const response = await fetch("https://api.indexnow.org/indexnow", {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({ host: "prophetic.pw", key: BING_INDEXNOW_API_KEY, keyLocation: `https://prophetic.pw/${BING_INDEXNOW_API_KEY}.txt`, urlList: urls }),
    });
    if (response.status === 200 || response.status === 202) {
      console.log(`  ✅ Bing IndexNow: ${urls.length} URLs submitted (${response.status})`);
    } else {
      console.warn(`  ⚠️  Bing IndexNow ${response.status}: ${await response.text()}`);
    }
  } catch (e) { console.error("  ❌ Bing IndexNow failed:", e.message); }
}

function baseStyles() {
  return `<style>
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Cairo','Segoe UI',system-ui,sans-serif;background:#0b1020;color:#e5e7eb;line-height:1.8;direction:rtl}
    .wrap{width:min(900px,94vw);margin:0 auto;padding:2rem 0 5rem}
    a{color:#a78bfa;text-decoration:none}a:hover{text-decoration:underline;color:#c4b5fd}
    .tag{display:inline-block;background:rgba(167,139,250,.15);color:#a78bfa;border:1px solid rgba(167,139,250,.3);font-size:.8rem;font-weight:700;padding:.3rem .8rem;border-radius:999px;margin-bottom:1.2rem;letter-spacing:.05em;text-transform:uppercase}
    h1{font-size:clamp(1.8rem,4vw,2.8rem);line-height:1.25;margin:.5rem 0 1.2rem;font-weight:800;color:#f9fafb}
    h2{font-size:1.7rem;margin:2rem 0 .8rem;color:#f3f4f6}h3{font-size:1.3rem;margin:1.5rem 0 .6rem;color:#e5e7eb}h4{font-size:1.1rem;margin:1.2rem 0 .5rem;color:#d1d5db}
    p{margin:0 0 1.2rem;line-height:1.9;color:#d1d5db}ul{padding-right:1.5rem;margin:1rem 0}li{margin-bottom:.5rem;color:#d1d5db}
    .meta{color:#6b7280;font-size:.9rem;margin-bottom:1.6rem;display:flex;gap:1rem;flex-wrap:wrap;align-items:center}
    .hero-img{width:100%;max-height:500px;object-fit:cover;border-radius:16px;margin:0 0 2rem;display:block}
    .lead{font-size:1.12rem;color:#9ca3af;margin-bottom:2rem;padding-bottom:2rem;border-bottom:1px solid #1f2937;line-height:1.9}
    .home-btn{display:inline-flex;align-items:center;gap:.5rem;margin-top:3rem;background:#111827;border:1px solid #374151;padding:.75rem 1.25rem;border-radius:.75rem;font-weight:600;color:#e5e7eb}
    .home-btn:hover{background:#1f2937;text-decoration:none;color:#e5e7eb}
    .nav-top{padding:1.2rem 0;margin-bottom:2rem;border-bottom:1px solid #1f2937;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem}
    .logo{font-size:1.5rem;font-weight:800;color:#f9fafb}.logo span{color:#a78bfa}
    .nav-links{display:flex;gap:1rem}.nav-links a{color:#9ca3af;font-size:.9rem}
    @media(max-width:600px){.nav-links{display:none}}
  </style>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap"/>`;
}

function baseHead({ title, description, canonical, image = DEFAULT_IMAGE, type = "website" }) {
  return `  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>${escapeHtml(title)}</title>
  <meta name="description" content="${escapeHtml(description)}"/>
  <meta name="robots" content="index,follow,max-image-preview:large,max-snippet:-1"/>
  <link rel="canonical" href="${canonical}"/>
  <meta property="og:type" content="${type}"/>
  <meta property="og:title" content="${escapeHtml(title)}"/>
  <meta property="og:description" content="${escapeHtml(description)}"/>
  <meta property="og:url" content="${canonical}"/>
  <meta property="og:image" content="${image}"/>
  <meta property="og:image:width" content="1200"/>
  <meta property="og:image:height" content="630"/>
  <meta property="og:image:alt" content="${escapeHtml(title)}"/>
  <meta property="og:site_name" content="${SITE_NAME}"/>
  <meta property="og:locale" content="ar_AR"/>
  <meta name="twitter:card" content="summary_large_image"/>
  <meta name="twitter:title" content="${escapeHtml(title)}"/>
  <meta name="twitter:description" content="${escapeHtml(description)}"/>
  <meta name="twitter:image" content="${image}"/>
  <meta name="twitter:image:alt" content="${escapeHtml(title)}"/>
  <meta name="twitter:site" content="@NeuralPost"/>
  <meta name="google-site-verification" content="LinTLA24lUQNkp3-Jnmx63UIro3uY1tF8Y9fN-XMrmk"/>
  <link rel="icon" type="image/x-icon" href="/favicon.ico"/>
  <link rel="manifest" href="/manifest.json"/>
  <meta name="theme-color" content="#4A235A"/>
  ${baseStyles()}`;
}

function navBar() {
  return `<nav class="nav-top"><a href="${SITE_URL}/" class="logo">Neural<span>Post</span></a><div class="nav-links"><a href="${SITE_URL}/category/AI/">الذكاء الاصطناعي</a><a href="${SITE_URL}/category/Tech/">التقنية</a><a href="${SITE_URL}/category/Business/">الأعمال</a><a href="${SITE_URL}/category/Science/">العلوم</a></div></nav>`;
}

async function generateArticleHtml(article) {
  const articleUrl = toAbsoluteUrl(`/article/${article.slug}`);
  let description = normalizeDescription(article.meta_description);
  if (!article.meta_description || article.meta_description.length < 100) {
    const gen = await generateUniqueDescription(article);
    if (gen) { description = gen; console.log(`  🤖 DeepSeek generated description for: ${article.slug}`); }
  }
  const title = `${article.title} | ${SITE_NAME}`;
  const imageUrl = article.image_url || DEFAULT_IMAGE;
  const publishDate = new Date(article.created_at).toLocaleDateString("ar-SA", { year: "numeric", month: "long", day: "numeric" });
  const articleSchema = JSON.stringify({
    "@context": "https://schema.org","@type": "NewsArticle","@id": `${articleUrl}#article`,
    headline: article.title, description,
    image: { "@type": "ImageObject", url: imageUrl, width: 1200, height: 630 },
    datePublished: article.created_at, dateModified: article.updated_at || article.created_at,
    author: { "@type": "Person", name: "NeuralPost AI", url: `${SITE_URL}/about/` },
    publisher: { "@type": "Organization", "@id": `${SITE_URL}/#organization`, name: SITE_NAME, logo: { "@type": "ImageObject", url: `${SITE_URL}/favicon.ico` } },
    mainEntityOfPage: { "@type": "WebPage", "@id": articleUrl },
    articleSection: article.category, isAccessibleForFree: true, inLanguage: "ar"
  });
  const breadcrumbSchema = JSON.stringify({
    "@context": "https://schema.org","@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "الرئيسية", item: `${SITE_URL}/` },
      { "@type": "ListItem", position: 2, name: categoryNames[article.category] || article.category, item: `${SITE_URL}/category/${article.category}/` },
      { "@type": "ListItem", position: 3, name: article.title, item: articleUrl }
    ]
  });
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
${baseHead({ title, description, canonical: articleUrl, image: imageUrl, type: "article" })}
  <meta property="article:published_time" content="${article.created_at}"/>
  <meta property="article:modified_time" content="${article.updated_at || article.created_at}"/>
  <meta property="article:section" content="${escapeHtml(article.category)}"/>
  <meta property="article:author" content="NeuralPost AI"/>
  <script type="application/ld+json">${articleSchema}</script>
  <script type="application/ld+json">${breadcrumbSchema}</script>
</head>
<body>
  <main class="wrap">
    ${navBar()}
    <article>
      <span class="tag">${escapeHtml(article.category)}</span>
      <h1>${escapeHtml(article.title)}</h1>
      <div class="meta"><time datetime="${article.created_at}">${publishDate}</time><span style="color:#374151">•</span><span>${SITE_NAME}</span></div>
      <img class="hero-img" src="${imageUrl}" alt="${escapeHtml(article.title)}" loading="eager" width="900" height="500"/>
      <p class="lead">${escapeHtml(description)}</p>
      <div>${markdownToHtml(article.content || article.meta_description || "")}</div>
    </article>
    <a class="home-btn" href="${SITE_URL}/">← العودة للرئيسية</a>
  </main>
</body>
</html>`;
}

function generateCategoryHtml(category, catArticles) {
  const url = toAbsoluteUrl(`/category/${category}`);
  const arabicName = categoryNames[category] || category;
  const description = `آخر أخبار ${arabicName} وتحليلات ${new Date().getFullYear()}. تغطية يومية شاملة على NeuralPost.`;
  const links = catArticles.slice(0, 50).map(a =>
    `<li style="margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid #1f2937"><a href="${toAbsoluteUrl(`/article/${a.slug}`)}" style="font-weight:600;font-size:1.05rem;color:#f3f4f6">${escapeHtml(a.title)}</a><div style="font-size:.85rem;color:#6b7280;margin-top:.3rem">${new Date(a.created_at).toLocaleDateString("ar-SA",{year:"numeric",month:"long",day:"numeric"})}</div></li>`
  ).join("\n");
  const breadcrumb = JSON.stringify({ "@context":"https://schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"name":"الرئيسية","item":`${SITE_URL}/`},{"@type":"ListItem","position":2,"name":arabicName,"item":url}] });
  return `<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head>\n${baseHead({ title: `أخبار ${arabicName} | ${SITE_NAME}`, description, canonical: url })}\n  <script type="application/ld+json">${breadcrumb}</script>\n</head>\n<body>\n  <main class="wrap">\n    ${navBar()}\n    <h1>أخبار ${escapeHtml(arabicName)}</h1>\n    <p style="color:#9ca3af;margin-bottom:2rem">${escapeHtml(description)}</p>\n    <ul style="list-style:none">${links || "<li style='color:#6b7280'>لا توجد مقالات حتى الآن.</li>"}</ul>\n    <a class="home-btn" href="${SITE_URL}/">← العودة للرئيسية</a>\n  </main>\n</body>\n</html>`;
}

function generateStaticPageHtml(page) {
  const url = toAbsoluteUrl(page.route);
  return `<!DOCTYPE html>\n<html lang="ar" dir="rtl">\n<head>\n${baseHead({ title: page.title, description: page.description, canonical: url })}\n</head>\n<body>\n  <main class="wrap">\n    ${navBar()}\n    <h1>${escapeHtml(page.heading)}</h1>\n    <p style="color:#9ca3af;margin-top:1rem;line-height:1.9">${escapeHtml(page.content)}</p>\n    <a class="home-btn" href="${SITE_URL}/">← العودة للرئيسية</a>\n  </main>\n</body>\n</html>`;
}

function generateSitemapIndex() {
  const today = new Date().toISOString().split("T")[0];
  return `<?xml version="1.0" encoding="UTF-8"?>\n<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <sitemap><loc>${SITE_URL}/sitemap-static.xml</loc><lastmod>${today}</lastmod></sitemap>\n  <sitemap><loc>${SITE_URL}/sitemap-articles.xml</loc><lastmod>${today}</lastmod></sitemap>\n</sitemapindex>`;
}

function generateStaticSitemap() {
  const today = new Date().toISOString().split("T")[0];
  const urls = [
    { loc: `${SITE_URL}/`, cf: "hourly", p: "1.0" },
    ...categories.map(c => ({ loc: `${SITE_URL}/category/${c}/`, cf: "daily", p: "0.9" })),
    ...staticPages.map(p => ({ loc: toAbsoluteUrl(p.route), cf: "monthly", p: "0.6" })),
  ];
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u => `  <url><loc>${u.loc}</loc><lastmod>${today}</lastmod><changefreq>${u.cf}</changefreq><priority>${u.p}</priority></url>`).join("\n")}\n</urlset>`;
}

function generateArticlesSitemap(articles) {
  let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">`;
  for (const a of articles) {
    const loc = toAbsoluteUrl(`/article/${a.slug}`);
    const lastmod = (a.updated_at || a.created_at || new Date().toISOString()).split("T")[0];
    xml += `\n  <url>\n    <loc>${loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>`;
    xml += `\n    <news:news><news:publication><news:name>${SITE_NAME}</news:name><news:language>ar</news:language></news:publication><news:publication_date>${a.created_at}</news:publication_date><news:title>${escapeHtml(a.title || "")}</news:title></news:news>`;
    if (a.image_url) xml += `\n    <image:image><image:loc>${a.image_url}</image:loc><image:title>${escapeHtml(a.title || "")}</image:title></image:image>`;
    xml += `\n  </url>`;
  }
  return xml + "\n</urlset>";
}

function generateRssXml(articles) {
  const items = articles.slice(0, 60).map(a => {
    const url = toAbsoluteUrl(`/article/${a.slug}`);
    return `    <item>\n      <title>${escapeHtml(a.title)}</title>\n      <link>${url}</link>\n      <guid isPermaLink="true">${url}</guid>\n      <pubDate>${new Date(a.created_at||Date.now()).toUTCString()}</pubDate>\n      <category>${escapeHtml(a.category)}</category>\n      <description><![CDATA[${normalizeDescription(a.meta_description)}]]></description>\n    </item>`;
  }).join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">\n  <channel>\n    <title>${SITE_NAME} - أخبار الذكاء الاصطناعي</title>\n    <link>${SITE_URL}/</link>\n    <description>آخر أخبار الذكاء الاصطناعي والتقنية والأعمال</description>\n    <language>ar</language>\n    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>\n    <atom:link href="${SITE_URL}/rss.xml" rel="self" type="application/rss+xml"/>\n    <managingEditor>touatihadi0@gmail.com (NeuralPost)</managingEditor>\n    <ttl>60</ttl>\n${items}\n  </channel>\n</rss>`;
}

async function main() {
  console.log("🚀 NeuralPost SSG starting...\n");
  const { data: articles, error } = await supabase.from("articles").select("id,title,slug,meta_description,content,category,image_url,created_at,updated_at").order("created_at", { ascending: false });
  if (error) { console.error("❌ Failed to fetch articles:", error.message); process.exit(1); }
  const safeArticles = Array.isArray(articles) ? articles : [];
  console.log(`✅ Loaded ${safeArticles.length} article(s)\n`);
  const distDir = path.join(__dirname, "..", "dist");
  ensureDir(distDir);
  const threeDaysAgo = Date.now() - 3 * 24 * 60 * 60 * 1000;
  const newUrls = [];

  console.log("📝 Generating article pages...");
  for (const article of safeArticles) {
    const html = await generateArticleHtml(article);
    writeRouteIndex(distDir, `/article/${article.slug}`, html);
    console.log(`  ✓ /article/${article.slug}/`);
    if (new Date(article.created_at).getTime() > threeDaysAgo) newUrls.push(toAbsoluteUrl(`/article/${article.slug}`));
  }

  console.log("\n📁 Generating category pages...");
  for (const cat of categories) {
    writeRouteIndex(distDir, `/category/${cat}`, generateCategoryHtml(cat, safeArticles.filter(a => a.category === cat)));
    console.log(`  ✓ /category/${cat}/`);
  }

  console.log("\n📄 Generating static pages...");
  for (const page of staticPages) {
    writeRouteIndex(distDir, page.route, generateStaticPageHtml(page));
    console.log(`  ✓ ${normalizeRoute(page.route)}`);
  }

  console.log("\n🗺️  Writing sitemaps...");
  fs.writeFileSync(path.join(distDir, "sitemap.xml"), generateSitemapIndex(), "utf8");
  console.log("  ✓ /sitemap.xml (index)");
  fs.writeFileSync(path.join(distDir, "sitemap-static.xml"), generateStaticSitemap(), "utf8");
  console.log("  ✓ /sitemap-static.xml");
  fs.writeFileSync(path.join(distDir, "sitemap-articles.xml"), generateArticlesSitemap(safeArticles), "utf8");
  console.log("  ✓ /sitemap-articles.xml");
  fs.writeFileSync(path.join(distDir, "rss.xml"), generateRssXml(safeArticles), "utf8");
  console.log("  ✓ /rss.xml");
  fs.writeFileSync(path.join(distDir, `${BING_INDEXNOW_API_KEY}.txt`), BING_INDEXNOW_API_KEY, "utf8");
  console.log(`  ✓ /${BING_INDEXNOW_API_KEY}.txt`);

  const allBingUrls = [`${SITE_URL}/`, ...categories.map(c => toAbsoluteUrl(`/category/${c}`)), ...newUrls];
  await submitToBingIndexNow(allBingUrls);

  console.log(`\n🎉 SSG completed! Articles: ${safeArticles.length} | Bing URLs: ${allBingUrls.length}`);
}

main().catch(err => { console.error("❌ SSG failed:", err); process.exit(1); });
